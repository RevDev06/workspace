package proyectorh;

import com.mysql.jdbc.Connection;       // Se importan las librerías necesarias para el buen funcionamiento de la
import java.sql.Date;                   // ventana, para hacer consultas, almacenarlas, manejar errores
import java.sql.ResultSet;              // o excepciones y manejar fechas de la manera que se requiera.
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.text.ParseException;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author oalme
 */
public class Requisicion extends javax.swing.JFrame {
    MySQL c = new MySQL();      // Se crea un objeto de la clase MySQL para acceder a sus métodos y a su variable
    Connection con;             // de conexión.
    
    public Requisicion() throws Exception {       // En el constructor se asigna a una variable la conexión de la clase
        this.con = c.MySQLConnection();           // MySQL, se inicializan los componentes, se establece la localización 
        initComponents();                         // de la ventana, su acción al cerrarla, se le pone título, además de
        setLocationRelativeTo(null);              // mostrar los datos que se requieran en la tabla, inhabilitar los 
        setDefaultCloseOperation(HIDE_ON_CLOSE);  // componentes del formato y ciertos botones y llenar el combo del área.
        setTitle("Requisición");
        mostrarDatos();
        inhabilitar();
        c.llenarCombo("area", "NombreArea", AreaSolicita);
        Autorizar.setEnabled(false);
        Borrar.setEnabled(false);
        EnviarReq.setEnabled(false);
    }
    
    
    /*Método para mostrar los datos más relevanes o básicos de la requisición en la tabla. Se crea un String con 
    los nombres de los campos que contendrá la tabla, un objeto de modelo para la tabla, y también el Query para
    realizar la consulta necesaria. Luego, con un try-catch, se ejecuta la sentencia Query y sus valores devueltos
    se almacenan en una variable de ResultSet, y mientras esa variable tenga valores guardados, se colocarán
    en los campos de la tabla. Si ocurre un error se mostrará cuál fue el error en un mensaje. */
    public void mostrarDatos() {
        String[] campos = {"Folio", "Puesto", "Área"};
        String[] registros = new String[3];
        DefaultTableModel modelo = new DefaultTableModel(null, campos);
        String Query = "select a.Folio, c.NombrePuesto, b.NombreArea from requisicion a, area b, puesto c "
                + "where a.Autorizada is null and a.idPuestoCubrir=c.idPuesto and a.idArea=b.idArea ";
        
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(Query);
            while (rs.next()) {
                registros[0] = rs.getString("Folio");
                registros[1] = rs.getString("NombrePuesto");
                registros[2] = rs.getString("NombreArea");
                modelo.addRow(registros);
            }
            TablaReq.setModel(modelo);
        } catch (SQLException e) {
            Logger.getLogger(Requisicion.class.getName()).log(Level.SEVERE, null, e);
            JOptionPane.showMessageDialog(null, "Error al mostrar los datos "+e.getMessage());
        }
    }
    
    
    /*Método para limpiar los campos de texto, los jDateChooser y colocar 
    el ítem por defecto en los ComboBox. */
    
    public void limpiar() {
        Folio.setText(null);
        AreaSolicita.setSelectedIndex(0);
        FechaElab.setDate(null);
        PuestoCubrir.setSelectedIndex(0);
        FechaReclu.setDate(null);
        FechaInicioV.setDate(null);
        TipoVacan.setSelectedIndex(0);
        CausaVacan.setSelectedIndex(0);
        Especifique.setText(null);
        NomSolicitan.setText(null);
        PuesSolicitan.setText(null);
        Turno.setText(null);
        DiasDesc.setText(null);
    }
    
    
    /*Método para inhabilitar los campos de texto, los componentes de tipo jCalendar y los ComboBox,
    esto para que no se pueda modificar la información que contengan al momento de querer consultar
    los datos de alguna Requisición. */
    
    public void inhabilitar() {
        Folio.setEditable(false);
        AreaSolicita.setEnabled(false);
        FechaElab.setEnabled(false);
        PuestoCubrir.setEnabled(false);
        FechaReclu.setEnabled(false);
        FechaInicioV.setEnabled(false);
        TipoVacan.setEnabled(false);
        CausaVacan.setEnabled(false);
        Especifique.setEditable(false);
        NomSolicitan.setEditable(false);
        PuesSolicitan.setEditable(false);
        Turno.setEditable(false);
        DiasDesc.setEditable(false);
    }
    
    
    /*Método para habilitar los campos de texto, los componentes de tipo jCalendar y los ComboBox, 
    esto para cuando se quiera solicitar (crear), una requisición. */
    
    public void habilitar() {
        Folio.setEditable(true);
        AreaSolicita.setEnabled(true);
        FechaElab.setEnabled(true);
        PuestoCubrir.setEnabled(true);
        FechaReclu.setEnabled(true);
        FechaInicioV.setEnabled(true);
        TipoVacan.setEnabled(true);
        CausaVacan.setEnabled(true);
        NomSolicitan.setEditable(true);
        PuesSolicitan.setEditable(true);
        Turno.setEditable(true);
        DiasDesc.setEditable(true);
    }
    
    
    /*Método para saber la diferencia entre las fechas seleccionadas en el formato de requisición.
    Crea una variable boolean que es inicializada como false, luego obtiene la diferencia entre la
    fecha de reclutamiento y la fecha de elaboración, y si es menor a 0 entonces se mostrará un
    mensaje diciendo que la fecha de reclutamiento no puede ser antes que la de elaboración;
    lo mismo hace con la fecha de inicio de la vacante y la de reclutamiento, estas operacones
    devuelven la diferencia en días. Después verifica que ambas diferencias de fechas sean mayores
    o iguales a 0 (en días), y si es así la variable boolean se hace verdadera, si no se queda como
    false. Si ocurre un error se mostrará en pantalla y la variable se hará false, finalmente retorna
    la variable para poder realizar operaciones con ella al momento de invocar el método.*/
    
    public boolean restarFechas() {
        SimpleDateFormat fecha = new SimpleDateFormat("yyyy/MM/dd");
        TimeUnit unidad = TimeUnit.DAYS; 
        boolean cierto = false;
        try {
            java.util.Date fechaelab = fecha.parse(fecha.format(FechaElab.getDate()));
            java.util.Date fecharecl = fecha.parse(fecha.format(FechaReclu.getDate()));
            long tiempo = fecharecl.getTime() - fechaelab.getTime();
            long dias = unidad.convert(tiempo, TimeUnit.MILLISECONDS);
            
            java.util.Date fechaini = fecha.parse(fecha.format(FechaInicioV.getDate()));
            long tiempo2 = fechaini.getTime() - fecharecl.getTime();
            long dias2 = unidad.convert(tiempo2, TimeUnit.MILLISECONDS);
            
            if (dias < 0) {
                JOptionPane.showMessageDialog(null, "La fecha de reclutamiento no puede ser antes de la fecha de elaboración de la requisición");
            }
            if (dias2 < 0) {
                JOptionPane.showMessageDialog(null, "La fecha de inicio de la vacante no puede ser antes de la fecha de reclutamiento");
            }
            
            cierto = dias >= 0 && dias2 >= 0;
            
        } catch (ParseException e) {
            cierto = false;
            JOptionPane.showMessageDialog(null, "Error al calcular las fechas "+e.toString());
            Logger.getLogger(Requisicion.class.getName()).log(Level.SEVERE, null, e);
        }
        return cierto;
    }
 
 
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Regresar = new javax.swing.JButton();
        Limpiar = new javax.swing.JButton();
        EnviarReq = new javax.swing.JButton();
        Borrar = new javax.swing.JButton();
        SolicitarReq = new javax.swing.JButton();
        Autorizar = new javax.swing.JButton();
        Especifique = new javax.swing.JTextField();
        PuesSolicitan = new javax.swing.JTextField();
        Folio = new javax.swing.JTextField();
        NomSolicitan = new javax.swing.JTextField();
        Turno = new javax.swing.JTextField();
        DiasDesc = new javax.swing.JTextField();
        AreaSolicita = new javax.swing.JComboBox();
        PuestoCubrir = new javax.swing.JComboBox();
        TipoVacan = new javax.swing.JComboBox();
        CausaVacan = new javax.swing.JComboBox();
        FechaInicioV = new com.toedter.calendar.JDateChooser();
        FechaElab = new com.toedter.calendar.JDateChooser();
        FechaReclu = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaReq = new javax.swing.JTable();
        jLabel15 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Regresar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Regresar.setText("Regresar");
        Regresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegresarActionPerformed(evt);
            }
        });
        getContentPane().add(Regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 5, 100, 30));

        Limpiar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Limpiar.setText("Limpiar");
        Limpiar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(Limpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 600, -1, -1));

        EnviarReq.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        EnviarReq.setText("Enviar requisición");
        EnviarReq.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EnviarReq.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EnviarReqActionPerformed(evt);
            }
        });
        getContentPane().add(EnviarReq, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 600, 145, -1));

        Borrar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Borrar.setText("Borrar");
        Borrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BorrarActionPerformed(evt);
            }
        });
        getContentPane().add(Borrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 600, 90, -1));

        SolicitarReq.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        SolicitarReq.setText("Solicitar requisición");
        SolicitarReq.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SolicitarReq.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SolicitarReqActionPerformed(evt);
            }
        });
        getContentPane().add(SolicitarReq, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 520, -1, -1));

        Autorizar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Autorizar.setText("Autorizar");
        Autorizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Autorizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AutorizarActionPerformed(evt);
            }
        });
        getContentPane().add(Autorizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 520, 90, -1));
        getContentPane().add(Especifique, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 385, 540, -1));
        getContentPane().add(PuesSolicitan, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 525, 260, -1));
        getContentPane().add(Folio, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 105, 260, -1));

        NomSolicitan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NomSolicitanActionPerformed(evt);
            }
        });
        getContentPane().add(NomSolicitan, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 525, 260, -1));
        getContentPane().add(Turno, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 455, 260, -1));
        getContentPane().add(DiasDesc, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 455, 260, -1));

        AreaSolicita.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Área" }));
        AreaSolicita.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        AreaSolicita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AreaSolicitaActionPerformed(evt);
            }
        });
        getContentPane().add(AreaSolicita, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 105, 260, -1));

        PuestoCubrir.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Puesto" }));
        PuestoCubrir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(PuestoCubrir, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 175, 260, -1));

        TipoVacan.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Tipo de vacante", "Temporal", "Permanente", "A obra y tiempo determinado", "Por honorarios" }));
        TipoVacan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(TipoVacan, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 315, 260, -1));

        CausaVacan.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Causa", "Incapacidad", "Baja", "Licencia", "Nueva creación", "Defunción", "Rescisión de contrato", "Cambio de residencia", "Promoción a puesto superior", "Otro" }));
        CausaVacan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        CausaVacan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CausaVacanActionPerformed(evt);
            }
        });
        getContentPane().add(CausaVacan, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 315, 260, -1));

        FechaInicioV.setDateFormatString("yyyy/MM/dd");
        getContentPane().add(FechaInicioV, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 245, 260, -1));

        FechaElab.setDateFormatString("yyyy/MM/dd");
        getContentPane().add(FechaElab, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 175, 260, -1));

        FechaReclu.setDateFormatString("yyyy/MM/dd");
        getContentPane().add(FechaReclu, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 245, 260, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Puesto a cubrir");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 150, 110, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Detalles:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 40, 110, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Requisición");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 5, 110, 30));

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setOpaque(true);
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1170, 40));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Folio");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 40, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Área que solicita");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 80, 120, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Fecha de inicio de vacante");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 220, 190, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Fecha de elaboración");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 150, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("Causa de la vacante");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 290, 150, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setText("Fecha de reclutamiento");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 170, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setText("Puesto del solicitante");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 500, 150, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel12.setText("Tipo de vacante");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 120, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setText("Especifique");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 90, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setText("Nombre del solicitante");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 500, 160, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel16.setText("Turno");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 430, 90, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel17.setText("Días de descanso");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 430, 120, -1));

        TablaReq.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        TablaReq.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaReqMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaReq);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 60, 600, 423));

        jLabel15.setBackground(new java.awt.Color(0, 0, 0));
        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Img_Requisicion.png"))); // NOI18N
        jLabel15.setOpaque(true);
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 1170, 650));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    /*Método que indica las acciones que realizará el botón Regresar al ser activado o clickeado.
    Crea un objeto de la clase Menu, y con este hace el jFrame de esta clase visible, al mismo tiempo
    que cierra la ventana de esta clase y libera los recursos utilizados para crear y mantener
    dicha ventana. */
    private void RegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegresarActionPerformed
        try {
            Menu menu = new Menu();
            menu.setVisible(true);
            this.dispose();
        } catch (Exception ex) {
            Logger.getLogger(Requisicion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_RegresarActionPerformed

    
    /*Método que indica las acciones que se realizarán al ser clickeado un registro de la tabla.
    Mediante un try-catch se obtiene el valor de la fila seleccionada, y en un String se almacena el 
    valor que hay en el primer campo de aquel registro que se clickeó en la tabla, luego se crea el 
    Query para hacer la consulta en la base de datos con el valor (folio) que se obtuvo de la fila
    seleccionada, después se ejecuta la sentencia y almacena los valores devueltos en una variable de 
    ResultSet; y mientas esa variable tenga valores almacenados, se accederá a ellos y colocarán en 
    los componentes del formato los valores que corresponden a cada uno, en caso de las fechas se
    convierten a valores tipo Date para que sean compatibles con los jDateChooser. Si ocurre un
    error se mostrará en mensaje. 
    Finalmente se inhabilitarán los campos del formato para que no se puedan modificar sus datos, el
    botón para enviar la requisición se inhabilitará y los botones Autorizar y Borrar se habilitarán.*/
    private void TablaReqMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaReqMouseClicked
        try {
            int filaselec = TablaReq.rowAtPoint(evt.getPoint());
            String folio =  TablaReq.getValueAt(filaselec, 0).toString();
            String Query = "select a.Folio, b.NombreArea, a.Fecha_elab, c.NombrePuesto, a.Fecha_recluta, "
                    + "a.Fecha_inicioV, a.TipoVacan, a.MotivoVacan, a.MotivoEspecif, a.Nombre_solicitante, "
                    + "a.Puesto_solicitante, a.Turno, a.DiasDescanso from requisicion a, area b, puesto c "
                    + "where a.idArea=b.idArea and a.idPuestoCubrir=c.idPuesto and a.Folio='"+folio+"'";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(Query);
            while (rs.next()) {
                Folio.setText(rs.getString("Folio"));
                AreaSolicita.setSelectedItem(rs.getString("NombreArea"));
                FechaElab.setDate(Date.valueOf(rs.getDate("Fecha_elab").toString()));
                PuestoCubrir.setSelectedItem(rs.getString("NombrePuesto"));
                FechaReclu.setDate(Date.valueOf(rs.getDate("Fecha_recluta").toString()));
                FechaInicioV.setDate(Date.valueOf(rs.getDate("Fecha_inicioV").toString()));
                TipoVacan.setSelectedItem(rs.getString("TipoVacan"));
                CausaVacan.setSelectedItem(rs.getString("MotivoVacan"));
                Especifique.setText(rs.getString("MotivoEspecif"));
                NomSolicitan.setText(rs.getString("Nombre_solicitante"));
                PuesSolicitan.setText(rs.getString("Puesto_solicitante"));
                Turno.setText(rs.getString("Turno"));
                DiasDesc.setText(rs.getString("DiasDescanso"));
            }

        } catch (NumberFormatException | SQLException e){
            JOptionPane.showMessageDialog(null, "Error al mostrar los datos "+e.getMessage());
        }
        inhabilitar();
        EnviarReq.setEnabled(false);
        Autorizar.setEnabled(true);
        Borrar.setEnabled(true);
    }//GEN-LAST:event_TablaReqMouseClicked

    
    /*Método para rellenar el ComboBox PuestoCubrir según los puestos que correspondan al área que
    fue seleccionada en el ComboBox AreaSolicita. Primero se coloca el ítem por defecto del ComboBox
    PuestoCubrir, luego con ayuda de un bucle se eliminarán todos los ítems que hay después del
    que hay por defecto en dicho componente, para que al momento de agregar los puestos que 
    corresponden al área seleccionada no se junten con los que habían rellenado el combo
    anteriormente. Luego con un try-catch se crea el String que contiene la consulta en SQL para
    seleccionar los puestos que correspondan con el área seleccionada, luego se rellenará el ComboBox
    con los valores que fueron devueltos por la consulta. Si ocurre un error se mostrará un mensaje.*/
    private void AreaSolicitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AreaSolicitaActionPerformed
        PuestoCubrir.setSelectedIndex(0);
        for (int i = PuestoCubrir.getItemCount() - 1; i > PuestoCubrir.getSelectedIndex(); i--) {
            PuestoCubrir.removeItemAt(i);
        }
        
        try {
            Statement st = con.createStatement();
            String query = "select idArea from area where NombreArea='"+AreaSolicita.getSelectedItem()+"'";
            ResultSet rs = st.executeQuery(query);
            int idarea = (rs.next()) ? rs.getInt("idArea") : AreaSolicita.getSelectedIndex();
            
            String Query = "select NombrePuesto from puesto where idArea="+idarea;
            rs = st.executeQuery(Query);
            while (rs.next()) {
                PuestoCubrir.addItem(rs.getString("NombrePuesto"));
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Error al mostrar los puestos correspondientes al área seleccionada "+e.toString());
        }
    }//GEN-LAST:event_AreaSolicitaActionPerformed

    
    /*Método que indica las acciones que realizará el botón Limpiar al ser activado o clickeado.
    Primero limpia los componentes del formato de requisición, luego el campo de texto Especifique
    es limpiado e inhabilitado, al igual que los botones Autorizar y Borrar.*/
    private void LimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LimpiarActionPerformed
        limpiar();
        Especifique.setText(null);
        Especifique.setEditable(false);
        Autorizar.setEnabled(false);
        Borrar.setEnabled(false);
    }//GEN-LAST:event_LimpiarActionPerformed

    
    /*Método que indica las acciones que realizará el boton SolicitarReq al ser activado o clickeado.
    Limpia los componentes del formato al igual que los habilita, el componente Especifique se inhabilita,
    al igual que los botones de Autorizar y Borrar, luego los botones de EnviarReq y Limpiar se habilitan.*/
    private void SolicitarReqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SolicitarReqActionPerformed
        limpiar();
        habilitar();
        Especifique.setEditable(false);
        EnviarReq.setEnabled(true);
        Limpiar.setEnabled(true);
        Autorizar.setEnabled(false);
        Borrar.setEnabled(false);
    }//GEN-LAST:event_SolicitarReqActionPerformed

    
    /*Al ser activado o clickeado el botón de EnviarReq, se verifica que todos los componentes, a excepción
    del componente Especifique, no sean nulos o no tengan el ítem por defecto en caso de los ComboBox, si es
    así se revisa la elección del ComboBox CausaVacan, si esta es "Otro" entonces se verificará si el componente
    Especifique no es vacío o nulo, si es así se revisa si el método restarFechas() devuelve verdadero, si sí
    entonces con un try-catch se crean sentencias SQL para obtener el ID de puesto y área, luego se llama al método
    agregarRequisicion() y se envían como argumentos los valores que se obtienen de los componentes y los ID's
    que se obtuvieron previamente, además revisa si el método devuelve verdadero para poder limpiar el formato,
    si ocurre un error en los try-catch, se mostrará en mensaje. SI restarFechas() devuelve false, significa que
    se debe escoger una fecha correcta y que cumpla con las condiciones de ese método, si Especifique está vacío
    se mostrará un mensaje diciendo que se debe llenar correctamente el componente. Si la elección del ComboBox
    CausaVacan no es "Otro", entonces se revisarán las mismas condicionales a excepción del que incluye al
    componente Especifique. Si la condición principal es falsa, se mostrará un mensaje diciendo que se deben
    llenar los campos correctamente. Posteriormente se llama al método mostrarDatos() para que muestre las
    actualizaciones en la tabla Requisicion en la base de datos. */
    private void EnviarReqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EnviarReqActionPerformed
        if (Folio.getText()!=null && !Folio.getText().trim().isEmpty() && AreaSolicita.getSelectedIndex()!=0 
        && FechaElab.getDate()!=null && PuestoCubrir.getSelectedIndex()!=0 && FechaReclu.getDate()!=null 
        && FechaInicioV.getDate()!=null && TipoVacan.getSelectedIndex()!=0 && CausaVacan.getSelectedIndex()!=0 
        && NomSolicitan.getText()!=null && !NomSolicitan.getText().trim().isEmpty() && PuesSolicitan.getText()!=null 
        && !PuesSolicitan.getText().trim().isEmpty() && Turno.getText()!=null && DiasDesc.getText()!=null
        && !Turno.getText().trim().isEmpty() && !DiasDesc.getText().trim().isEmpty()) {
            
            if (CausaVacan.getSelectedItem()=="Otro") {
                
                if (Especifique.getText()!=null && !Especifique.getText().trim().isEmpty()) {
                
                    if (restarFechas()) {
                        try {
                            Statement st = con.createStatement();
                            String Query = "SELECT idArea FROM area WHERE NombreArea='"+AreaSolicita.getSelectedItem()+"'";
                            ResultSet rs = st.executeQuery(Query);
                            int idarea = (rs.next()) ? rs.getInt("idArea") : AreaSolicita.getSelectedIndex();
                            
                            String Query2 = "SELECT idPuesto FROM puesto WHERE NombrePuesto='"+PuestoCubrir.getSelectedItem()+"'";
                            rs = st.executeQuery(Query2);
                            int idpuestocubrir = (rs.next()) ? rs.getInt("idPuesto") : PuestoCubrir.getSelectedIndex();

                            SimpleDateFormat fecha = new SimpleDateFormat("yyyy/MM/dd");
                            
                            if (c.agregarRequisicion(Folio.getText().trim(), idpuestocubrir, fecha.format(FechaElab.getDate()), 
                                fecha.format(FechaReclu.getDate()), fecha.format(FechaInicioV.getDate()), 
                                TipoVacan.getSelectedItem().toString(), CausaVacan.getSelectedItem().toString(), 
                                Especifique.getText().trim(), NomSolicitan.getText().trim(),PuesSolicitan.getText().trim(), 
                                idarea, Turno.getText().trim(), DiasDesc.getText().trim())) {
                                    limpiar();
                            } 

                        } catch (SQLException e) {
                            JOptionPane.showMessageDialog(null, "Errooor "+e.toString());
                        } catch (Exception ex) {
                            Logger.getLogger(Requisicion.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Escoja otra fecha ");
                    }
                    
                } else {
                    JOptionPane.showMessageDialog(null, "Debe llenar correctamente el campo");
                }
                
            } else {
                if (restarFechas()) { 
                    try {
                        Statement st = con.createStatement();
                        String Query = "SELECT idArea FROM area WHERE NombreArea='"+AreaSolicita.getSelectedItem()+"'";
                        ResultSet rs = st.executeQuery(Query);
                        int idarea = (rs.next()) ? rs.getInt("idArea") : AreaSolicita.getSelectedIndex();
                        
                        String Query2 = "SELECT idPuesto FROM puesto WHERE NombrePuesto='"+PuestoCubrir.getSelectedItem()+"'";
                        rs = st.executeQuery(Query2);
                        int idpuestocubrir = (rs.next()) ? rs.getInt("idPuesto") : PuestoCubrir.getSelectedIndex();

                        SimpleDateFormat fecha = new SimpleDateFormat("yyyy/MM/dd");
                        
                        if (c.agregarRequisicion(Folio.getText().trim(), idpuestocubrir, fecha.format(FechaElab.getDate()), 
                            fecha.format(FechaReclu.getDate()), fecha.format(FechaInicioV.getDate()), 
                            TipoVacan.getSelectedItem().toString(), CausaVacan.getSelectedItem().toString(), 
                            Especifique.getText().trim(), NomSolicitan.getText().trim(),PuesSolicitan.getText().trim(), 
                            idarea, Turno.getText().trim(), DiasDesc.getText().trim())) {
                                limpiar();
                        }

                    } catch (SQLException e) {
                        JOptionPane.showMessageDialog(null, "Erroor "+e.toString());
                    } catch (Exception ex) {
                        Logger.getLogger(Requisicion.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                } else {
                    JOptionPane.showMessageDialog(null, "Escoja otra fecha");
                }
            }
            
        } else {
            JOptionPane.showMessageDialog(null, "Debe llenar correctamente los campos");
        }
        mostrarDatos();
    }//GEN-LAST:event_EnviarReqActionPerformed

    
    /*Método que indica las accones que realizará el botón Borrar al ser activado o clickeado.
    Invoca al método eliminarRequisicion() de la clase MySQL y le envía como argumento el folio
    del puesto que se ha consultado, luego se actualizan los datos de la tabla con el método 
    mostrarDatos(), limpia los componentes e inhabilita los botones de Autorizar y Borrar.*/
    private void BorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BorrarActionPerformed
        c.eliminarRequisicion(Folio.getText());
        mostrarDatos();
        limpiar();
        Autorizar.setEnabled(false);
        Borrar.setEnabled(false);
    }//GEN-LAST:event_BorrarActionPerformed

    
    /*Si la elección del ComboBox CausaVacan es "Otro" entonces el componente Especifique se habilitará
    y se podrá escribir información en él. Si no es así entonces se limpiará el campo de texto y se 
    inhabilitará.*/
    private void CausaVacanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CausaVacanActionPerformed
        if (CausaVacan.getSelectedItem()=="Otro") {
            Especifique.setEditable(true);
        } else {
            Especifique.setText(null);
            Especifique.setEditable(false);
        }
    }//GEN-LAST:event_CausaVacanActionPerformed

    
    /*Al momento de dar click en Autorizar, entonces se creará un objeto de la clase
    AutorizarRequisicion, con ayuda de este objeto el jFrame de dicha clase se hará visible, 
    y en sus campos de texto Folio1, PuestoVacante y AreaVacante se colocará el texto
    que hay en sus homólogos de la ventana de esta clase, finalmente este jFrame
    lo cierra y libera sus recursos. */
    private void AutorizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AutorizarActionPerformed
        try {
            AutorizarRequisicion ventanaAureq = new AutorizarRequisicion();
            ventanaAureq.setVisible(true);
            ventanaAureq.Folio1.setText(Folio.getText());
            ventanaAureq.PuestoVacante.setText(PuestoCubrir.getSelectedItem().toString());
            ventanaAureq.AreaVacante.setText(AreaSolicita.getSelectedItem().toString());
            this.dispose();
        } catch (Exception ex) {
            Logger.getLogger(Requisicion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_AutorizarActionPerformed

    private void NomSolicitanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NomSolicitanActionPerformed
        
    }//GEN-LAST:event_NomSolicitanActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Requisicion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Requisicion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Requisicion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Requisicion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Requisicion().setVisible(true);
                } catch (Exception ex) {
                    Logger.getLogger(Requisicion.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JComboBox AreaSolicita;
    private javax.swing.JButton Autorizar;
    private javax.swing.JButton Borrar;
    private javax.swing.JComboBox CausaVacan;
    public javax.swing.JTextField DiasDesc;
    private javax.swing.JButton EnviarReq;
    private javax.swing.JTextField Especifique;
    private com.toedter.calendar.JDateChooser FechaElab;
    private com.toedter.calendar.JDateChooser FechaInicioV;
    private com.toedter.calendar.JDateChooser FechaReclu;
    public javax.swing.JTextField Folio;
    private javax.swing.JButton Limpiar;
    private javax.swing.JTextField NomSolicitan;
    private javax.swing.JTextField PuesSolicitan;
    public javax.swing.JComboBox PuestoCubrir;
    private javax.swing.JButton Regresar;
    private javax.swing.JButton SolicitarReq;
    private javax.swing.JTable TablaReq;
    private javax.swing.JComboBox TipoVacan;
    public javax.swing.JTextField Turno;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
