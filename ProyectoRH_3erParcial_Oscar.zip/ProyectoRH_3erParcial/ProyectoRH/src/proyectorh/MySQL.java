package proyectorh;

import com.mysql.jdbc.Connection;     // Se importan las librerias necesarias para hacer 
import java.awt.HeadlessException;    // la conexión a la base de datos y para crear tablas, 
import java.sql.DriverManager;        // además de agregar registros mediante INSERT, 
import java.sql.ResultSet;            // actualizar registros mediante UPDATE, y eliminar 
import java.sql.SQLException;         // mediante DELETE; y si ocurre un error que 
import java.sql.Statement;            // sea mostrado en pantalla.
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class MySQL {
    Connection Conexion;    // Variable para la conexión.
     
    
    /* Método para realizar la conexión a la base de datos, retorna la variable Conexion para ser usada 
    al momento de que se llame al método. */
    public Connection MySQLConnection () throws Exception {     
        try {                                                    
            Class.forName("com.mysql.jdbc.Driver");
            Conexion = (Connection) DriverManager.getConnection ("jdbc:mysql://localhost:3307/recursoshumanos","root", "");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Conexion;
    }
    
    public void closeConnection () {        // Método para cerrar la conexión.
        try {
            Conexion.close();
        } catch (SQLException ex) {
            Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    /* Método para crear la tabla Puesto en la base de datos, si ocurre un error lanzará 
    una Excepción de SQL. executeUpdate() es para actualizaciones en una base de datos.*/
    public void createTablePuesto () {      
        try {
            String Query = "CREATE TABLE IF NOT EXISTS Puesto (idPuesto INT AUTO_INCREMENT UNIQUE, NombrePuesto VARCHAR(60) UNIQUE, "
                    + "Puesto_jefesup VARCHAR(60), Salario VARCHAR(15), Descripcion VARCHAR(150), "
                    + "Edad VARCHAR(30), Sexo VARCHAR(20), Experiencia VARCHAR(100), Conocimientos VARCHAR(150), "
                    + "ManejoEquipo VARCHAR(100), Reqfisicos VARCHAR(100), Reqpsicol VARCHAR(100), Responsabilidades VARCHAR(150), "
                    + "CondicionesTrab VARCHAR(100), idArea INT, idCarrera INT, idEscolaridad INT, idEstadoCivil INT, "
                    + "idGradoAvance INT, idIdioma INT, PRIMARY KEY(idPuesto))";
            Statement st = Conexion.createStatement();
            st.executeUpdate(Query);                        
            
        } catch (SQLException ex) {
            Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /* Método para crear la tabla Requisición en la base de datos, si ocurre un error 
    lanzará una Excepción de SQL. */
    public void createTableRequisicion () {     
        try {
            String Query = "CREATE TABLE IF NOT EXISTS Requisicion (idRequisicion INT AUTO_INCREMENT UNIQUE, Folio VARCHAR(5) UNIQUE, "
                    + "idPuestoCubrir INT, Fecha_elab DATE, Nombre_solicitante VARCHAR(60), Puesto_solicitante VARCHAR(60), "
                    + "Fecha_recluta DATE, Fecha_inicioV DATE, TipoVacan VARCHAR(45), MotivoVacan VARCHAR(45), MotivoEspecif VARCHAR(100), "
                    + "Turno VARCHAR(45), DiasDescanso VARCHAR(100), idArea INT, Autorizada VARCHAR(2), NombreRevisa VARCHAR(60), "
                    + "PuestoRevisa VARCHAR(60), NombreAutoriza VARCHAR(60), PuestoAutoriza VARCHAR(60), PRIMARY KEY(idRequisicion))";
            Statement st = Conexion.createStatement();
            st.executeUpdate(Query);
            
        } catch (SQLException ex) {
            Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /*Método para crear la tabla Área en la base de datos, si ocurre un error 
    lanzará una Excepción de SQL. */
    public void createTableArea () {        
        try {
            String Query = "CREATE TABLE IF NOT EXISTS Area (idArea INT AUTO_INCREMENT UNIQUE, "
                    + "NombreArea VARCHAR(45) UNIQUE, PRIMARY KEY(idArea))";
            Statement st = Conexion.createStatement();
            st.executeUpdate(Query);
            
        } catch (SQLException ex) {
            Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /* Método para crear la tabla Carrera en la base de datos, si ocurre un error 
    lanzará una Excepción de SQL. */
    public void createTableCarrera () {     
        try {
            String Query = "CREATE TABLE IF NOT EXISTS Carrera (idCarrera INT AUTO_INCREMENT UNIQUE, "
                    + "NombreCarre VARCHAR(45) UNIQUE, PRIMARY KEY(idCarrera))";
            Statement st = Conexion.createStatement();
            st.executeUpdate(Query);
            
        } catch (SQLException ex) {
            Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /* Método para crear la tabla Escolaridad en la base de datos, si ocurre 
    un error lanzará una Excepción de SQL. */
    public void createTableEscolaridad () {     
        try {
            String Query = "CREATE TABLE IF NOT EXISTS Escolaridad (idEscolaridad INT AUTO_INCREMENT UNIQUE, "
                    + "NombreEsco VARCHAR(45) UNIQUE, PRIMARY KEY(idEscolaridad))";
            Statement st = Conexion.createStatement();
            st.executeUpdate(Query);
            
        } catch (SQLException ex) {
            Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /* Método para crear la tabla EdoCivil en la base de datos, si ocurre 
    un error lanzará una Excepción de SQL. */
    public void createTableEstadoCivil () {     
        try {
            String Query = "CREATE TABLE IF NOT EXISTS EdoCivil (idEdoCivil INT AUTO_INCREMENT UNIQUE, "
                    + "EstadoCiv VARCHAR(45) UNIQUE, PRIMARY KEY(idEdoCivil))";
            Statement st = Conexion.createStatement();
            st.executeUpdate(Query);
            
        } catch (SQLException ex) {
            Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /* Método para crear la tabla GdoAvance en la base de datos, 
    si ocurre un error lanzará una Excepción de SQL. */
    public void createTableGradoAvance () {     
        try {
            String Query = "CREATE TABLE IF NOT EXISTS GdoAvance (idGdoAvance INT AUTO_INCREMENT UNIQUE, "
                    + "NombreGA VARCHAR(45) UNIQUE, PRIMARY KEY(idGdoAvance))";
            Statement st = Conexion.createStatement();
            st.executeUpdate(Query);
            
        } catch (SQLException ex) {
            Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /* Método para crear la tabla Idioma en la base de datos, 
    si ocurre un error lanzará una Excepción de SQL. */
    public void createTableIdioma () {      
        try {
            String Query = "CREATE TABLE IF NOT EXISTS Idioma (idIdioma INT AUTO_INCREMENT UNIQUE, "
                    + "NomIdioma VARCHAR(45) UNIQUE, PRIMARY KEY(idIdioma))";
            Statement st = Conexion.createStatement();
            st.executeUpdate(Query);
            
        } catch (SQLException ex) {
            Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /* Método para rellenar los combos que sean necesarios con la información 
    o campos que se requieran. 
    executeQuery(); es para ejecutar consultas. */
    public void llenarCombo(String tabla, String campo, JComboBox combo) {  
        try {
            String Query = "SELECT * FROM " + tabla;
            Statement st = Conexion.createStatement();
            ResultSet rs = st.executeQuery(Query);      
            while (rs.next()){
                combo.addItem(rs.getString(campo));
            }
            
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null, "Error al llenar el ComboBox "+ex.toString());
        }
    }
    
    
    /* Método para insertar registros en la tabla Puesto. Recibe como parámetros variables que son enviadas
    y convertidas en String o int desde la clase que se llame al método. Estas variables recibidas se combinarán
    con el String Query para realizar la ejecución en SQL. Inicializa una variable boolean que la retornará 
    dependiendo de lo que realice o suceda, y que nos servirá para realizar más operaciones en la clase en que sea invocada. 
    Si ocurre un error, este se mostraá en pantalla*/
    
    public boolean insertPuesto(String nombre, String puestojs, int salario, String descripcion, String edad, String sexo, 
            String exp, String conocimientos, String manejoeq, String reqfisic, String reqpsico, String respons, 
            String condictrab, int idarea, int idcarre, int idescol, int idedocivil, int idgdoavan, int ididioma) {
        boolean proceder;
        try {
            String Query = "INSERT INTO puesto (NombrePuesto, Puesto_jefesup, Salario, Descripcion, Edad, Sexo, Experiencia, "
                    + "Conocimientos, ManejoEquipo, Reqfisicos, Reqpsicol, Responsabilidades, CondicionesTrab, idArea, idCarrera, "
                    + "idEscolaridad, idEstadoCivil, idGradoAvance, idIdioma) VALUES ('"+ nombre +"', '"+ puestojs +"', "+ salario 
                    +", '"+ descripcion +"', '"+ edad +"', '"+ sexo +"', '"+ exp +"', '"+ conocimientos +"', '"+ manejoeq +"', '"+
                    reqfisic +"', '"+ reqpsico +"', '"+ respons +"', '"+ condictrab +"', "+ idarea +", "+ idcarre +", "+ idescol 
                    +", "+ idedocivil +", "+ idgdoavan +", "+ ididioma +")";
            Statement st = Conexion.createStatement();
            st.executeUpdate(Query);
            proceder = true;
        } catch (SQLException ex){
            proceder = false;
            JOptionPane.showMessageDialog(null, "Error al agregar el puesto "+ex.toString());
        }
        return proceder;
    }
    
    
    /*Método para editar la tabla Puesto. Recibe valores convertidos en int y String, y los combina con el String
    de sql para su ejecución. Se crea una variable boolean para realizar más operaciones cuando sea invocado el método. 
    Si ocurre un error, este se mostrará en pantalla. */
    
    public boolean editarPuesto(int idPuesto, String nombre, String puestojs, int salario, String descripcion, String edad, 
            String sexo, String exp, String conocimientos, String manejoeq, String reqfisic, String reqpsico, String respons, 
            String condictrab, int idarea, int idcarre, int idescol, int idedocivil, int idgdoavan, int ididioma) {
        boolean proceder;
        try {
            Statement st = Conexion.createStatement();
            String Query = "UPDATE puesto SET NombrePuesto='"+ nombre +"', Puesto_jefesup='"+ puestojs +"', Salario="+ salario 
                   +", Descripcion='"+ descripcion +"', Edad='"+ edad +"', Sexo='"+ sexo +"', Experiencia='"+ exp 
                   +"', Conocimientos='"+ conocimientos +"', ManejoEquipo='"+ manejoeq +"', Reqfisicos='"+ reqfisic +"', "
                   +"Reqpsicol='"+ reqpsico +"', Responsabilidades='"+ respons +"', CondicionesTrab='"+ condictrab 
                   +"', idArea="+ idarea +", idCarrera="+ idcarre +", idEscolaridad="+ idescol +", idEstadoCivil="+ idedocivil 
                   +", idGradoAvance="+ idgdoavan +", idIdioma="+ ididioma +" WHERE idPuesto="+ idPuesto;
            st.executeUpdate(Query);
            proceder = true;
        } catch (SQLException e) {
            proceder = false;
            JOptionPane.showMessageDialog(null, "Error al editar el puesto " + e.toString());
        }
        return proceder;
    }
    
    
    /*Método para eliminar un registro deseado de la tabla Puesto. Si ocurre un error, este se mostrará en pantalla. */
    
    public void eliminarPuesto(int idPuesto) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "DELETE FROM puesto WHERE idPuesto = " + idPuesto;
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Error al eliminar el puesto " + e.toString());
        }
    }
    
    
    /*Método para agregar un registro al catálogo Area. Si ocurre un error, se mostrará en mensaje.*/
    
    public void agregarArea(String nombre) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "INSERT INTO area (NombreArea) VALUES ('"+ nombre +"')";
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al agregar el área "+e.toString());
        }
    }
    
    
    /*Método para editar algún registro del catálogo Area. Si ocurre un error se mostrará en mensaje. */
    
    public void editarArea(int idarea, String nombre) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "UPDATE area SET NombreArea='"+ nombre +"' WHERE idArea="+ idarea;
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al editar el área "+ e.toString());
        }
    }
    
    
    /*Método para eliminar un registro del catálogo Area. Si ocurre un error se mostrará en mensaje. */
    
    public void eliminarArea(int idarea) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "DELETE FROM area WHERE idArea="+ idarea;
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Error al eliminar el area " + e.toString());
        }
    }
    
    
    /*Método para agregar un registro al catálogo Idioma. Si ocurre un error se mostrará en mensaje. */
    
    public void agregarIdioma(String nombre) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "INSERT INTO idioma (NomIdioma) VALUES ('"+ nombre +"')";
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al agregar el idioma "+ e.toString());
        }
    }
    
    
    /*Método para editar un registro del catálogo Idioma. Si ocurre un error se mostrará en mensaje. */
    
    public void editarIdioma(int ididioma, String nombre) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "UPDATE idioma SET NomIdioma='"+ nombre +"' WHERE idIdioma="+ididioma;
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al editar el idioma "+ e.toString());
        }
    }
    
    
    /*Método para eliminar un registro del catálogo Idioma. Si ocurre un error se mostrará en mensaje. */
    
    public void eliminarIdioma(int ididioma) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "DELETE FROM idioma WHERE idIdioma="+ ididioma;
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar el idioma "+e.toString());
        }
    }
    
    
    /*Método para agregar un registro al catálogo EdoCivil. Si ocurre un error se mostrará en mensaje. */
    
    public void agregarEdoCivil(String nombre) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "INSERT INTO edocivil (EstadoCiv) VALUES ('"+ nombre +"')";
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al agregar el estado civil "+e.toString());
        }
    }
    
    
    /*Método para editar un registro del catálogo EdoCivil. Si ocurre un error se mostrará en mensaje. */
    
    public void editarEdoCivil(int idedocivil, String nombre) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "UPDATE edocivil SET EstadoCiv='"+ nombre +"' WHERE idEdoCivil="+idedocivil;
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al editar el estado civil "+e.toString());
        }
    }
    
    
    /*Método para eliminar un registro del catálogo EdoCivil. Si ocurre un error se mostrará en mensaje. */
    
    public void eliminarEdoCivil(int idedocivil) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "DELETE FROM edocivil WHERE idEdoCivil="+idedocivil;
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar el estado civil "+e.toString());
        }
    }
    
    
    /*Método para agregar un registro al catálogo GdoAvance. Si ocurre un error se mostrará en mensaje. */
     
    public void agregarGdoAvan(String nombre) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "INSERT INTO gdoavance (NombreGA) VALUES ('"+ nombre +"')";
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al agregar el grado de avance "+ e.toString());
        }
    }
    
    
    /*Método para editar un registro del catálogo GdoAvance. Si ocurre un error se mostrará en mensaje. */
    
    public void editarGdoAvan(int idgdoavan, String nombre) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "UPDATE gdoavance SET NombreGA='"+ nombre +"' WHERE idGdoAvance="+idgdoavan;
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al editar el grado de avance "+ e.toString());
        }
    }
    
    
    /*Método para eliminar un registro del catálogo GdoAvance. Si ocurre un error se mostrará en mensaje. */
    
    public void eliminarGdoAvan(int idgdoavan) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "DELETE FROM gdoavance WHERE idGdoAvance="+idgdoavan;
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar el grado de avance "+ e.toString());
        }
    }
    
    
    /*Método para agregar un registro al catálogo Escolaridad. Si ocurre un error se mostrará en mensaje. */
    
    public void agregarEscolaridad (String nombre) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "INSERT INTO escolaridad (NombreEsco) VALUES ('"+ nombre +"')";
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al agregar la escolaridad "+ e.toString());
        }
    }
    
    
    /*Método para editar un registro del catálogo Escolaridad. Si ocurre un error se mostrará en mensaje. */
    
    public void editarEscolaridad(int idescol, String nombre) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "UPDATE escolaridad SET NombreEsco='"+ nombre +"' WHERE idEscolaridad="+idescol;
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al editar la escolaridad "+e.toString());
        }
    }
    
    
    /*Método para eliminar un registro del catálogo Escolaridad. Si ocurre un error se mostrará en mensaje. */
    
    public void eliminarEscolaridad(int idescol) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "DELETE FROM escolaridad WHERE idEscolaridad="+idescol;
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar la escolaridad "+e.toString());
        }
    }
    
    
    /*Método para agregar un registro al catálogo Carrera. Si ocurre un error se mostrará en mensaje. */
    
    public void agregarCarrera(String nombre) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "INSERT INTO carrera (NombreCarre) VALUES ('"+ nombre +"')";
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al agregar la carrera "+e.toString());
        }
    }
    
    
    /*Método para editar un registro del catálogo Carrera. Si ocurre un error se mostrará en mensaje. */
    
    public void editarCarrera(int idcarrera, String nombre) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "UPDATE carrera SET NombreCarre='"+ nombre +"' WHERE idCarrera="+idcarrera;
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al editar la carrera "+e.toString());
        }
    }
    
    
    /*Método para eliminar un registro del catálogo Carrera. Si ocurre un error se mostrará en mensaje. */
    
    public void eliminarCarrera(int idcarrera) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "DELETE FROM carrera WHERE idCarrera="+idcarrera;
            st.executeUpdate(Query);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar la carrera "+e.toString());
        }
    }
    
    
    /*Método para agregar registros a la tabla Requisición. Crea una variable boolean que la retorna dependiendo
    de lo que suceda o realice el método, esta servirá para realizar operaciones en la clase que se invoque. 
    Si ocurre un error se mostrará en mensaje. */
    
    public boolean agregarRequisicion(String folio, int idpuescubrir, String fechaelab, String fecharecl, 
            String fechainv, String tipovac, String causavac, String especif, String nomsolic, String puestsolic, 
            int idarea, String turno, String diasdesc) throws Exception {
        boolean proceder;
        try {
            Statement st = Conexion.createStatement();
            String Query = "INSERT INTO requisicion (Folio, idPuestoCubrir, Fecha_elab, Fecha_recluta, "
                    + "Fecha_inicioV, TipoVacan, MotivoVacan, MotivoEspecif, Nombre_solicitante, Puesto_solicitante, "
                    + "idArea, Turno, DiasDescanso) VALUES ('"+folio+"', "+idpuescubrir+", '"+fechaelab+"', '"+
                    fecharecl+"', '"+fechainv+"', '"+tipovac+"', '"+causavac+"', '"+especif+"', '"+nomsolic
                    +"', '"+puestsolic+"', "+idarea+", '"+turno+"', '"+diasdesc+"')";
            st.executeUpdate(Query);
            proceder = true;
            JOptionPane.showMessageDialog(null, "Se ha solicitado la requisición");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al enviar la requisición "+e.toString());
            proceder = false;
        }
        return proceder;
    }
    
    
    /*Método para actualizar la tabla Requisición. Sirve para autorizar una requisición anteriormente
    guardada, y que, a su vez, servirá para mostrar las vacantes. Si ocurre un error se mostrará en mensaje.*/
    
    public void actualizarRequisicion(String folio, String nomrevisa, String puestrevisa, String nomautoriza, String puestoautoriza) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "UPDATE requisicion SET Autorizada='Sí', NombreRevisa='"+ nomrevisa 
                    +"', PuestoRevisa='"+ puestrevisa +"', NombreAutoriza='"+ nomautoriza 
                    +"', PuestoAutoriza='"+ puestoautoriza +"' WHERE Folio='"+ folio +"'";
            st.executeUpdate(Query);
            JOptionPane.showMessageDialog(null, "Requisición autorizada");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al autorizar la requisición "+e.toString());
        }
    } 
    
    
    /*Método para eliminar un registro de la tabla Requisición. Sirve para determinar aquellas requisiciones
    que no se autorizan o que contienen errores. Si ocurre un error se mostrará en mensaje.*/
    
    public void eliminarRequisicion(String folio) {
        try {
            Statement st = Conexion.createStatement();
            String Query = "DELETE FROM requisicion WHERE Folio='"+ folio +"'";
            st.executeUpdate(Query);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar la requisicion "+e.toString());
        }
    }
}