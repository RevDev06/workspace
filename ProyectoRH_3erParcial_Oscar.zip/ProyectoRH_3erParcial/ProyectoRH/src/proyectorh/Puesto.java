package proyectorh;

import com.mysql.jdbc.Connection;    // Se importan las librerías necesarias para el buen funcionamiento de la ventana Puesto,
import java.sql.ResultSet;           // para hacer consultas, almacenarlas y manejar errores que puedan surgir.                                   
import java.sql.SQLException;        
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author oalme
 */
public class Puesto extends javax.swing.JFrame {
    MySQL c = new MySQL();          // Se crea un objeto de la clase "MySQL" para acceder a sus métodos y variable de conexión.
    Connection con;
    
    public Puesto() throws Exception {            // En el constructor se le asigna a una variable la conexión creada en la clase
        this.con = c.MySQLConnection();           // MySQL, además de inicializar los componentes, establecer la localización de 
        initComponents();                         // la ventana, ponerle título, establecer su acción al cerrar la ventana,
        setLocationRelativeTo(null);              // mostrar los datos de Puesto, rellenar los combos necesarios e inhabilitar
        setDefaultCloseOperation(HIDE_ON_CLOSE);  // algunos botones. 
        setTitle("Puesto");
        mostrarDatos();
        RellenarCombos();
        Editar.setEnabled(false);
        Agregar.setEnabled(false);
        EditarPuesto.setEnabled(false);
        EliminarPuesto.setEnabled(false);
        inhabilitar();
    } 

    
    /* Método para mostrar los datos de Puesto más relevantes o básicos en una tabla, crea un String con los nombres 
    de los campos, crea un objeto para establecer el modelo de la tabla, utiliza una sentencia SQL para ejecutar la
    consulta y los almacena en una variable, y mientras esa variable tenga datos almacenados los colocará en las 
    columnas de la tabla. Si ocurre un error mostrando los datos, se mostrará un mensaje diciendo cuál fue el error.*/
    
    public void mostrarDatos() {
        String[] campos = {"Código de Puesto", "Nombre", "Salario"};
        String[] registros = new String[3];
        DefaultTableModel modelo = new DefaultTableModel(null, campos);
        String Query = "select idPuesto, NombrePuesto, Salario from puesto";
        
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(Query);
            while (rs.next()) {
                registros[0] = rs.getString("idPuesto");
                registros[1] = rs.getString("NombrePuesto");
                registros[2] = rs.getString("Salario");
                modelo.addRow(registros);
            }
            TablaPuesto.setModel(modelo);
        } catch (SQLException e) {
            Logger.getLogger(Puesto.class.getName()).log(Level.SEVERE, null, e);
            JOptionPane.showMessageDialog(null, "Error al mostrar los datos "+e.getMessage());
        }
    }
    
    
    /*Método para rellenar los ComboBox con la información que se requiere. Llama al método llenarCombo()
    de la clase MySQL, y le manda como argumentos el nombre de la tabla de la que se quiere acceder a su 
    información, además del campo específico del que se extraerán los datos y el nombre del ComboBox
    que será rellenado. */
    
    public void RellenarCombos() {
        c.llenarCombo("area", "NombreArea", Area);
        c.llenarCombo("carrera", "NombreCarre", Carrera);
        c.llenarCombo("edocivil", "EstadoCiv", EstadoCivil);
        c.llenarCombo("escolaridad", "NombreEsco", Escolaridad);
        c.llenarCombo("gdoavance", "NombreGA", GradoAvance);
        c.llenarCombo("idioma", "NomIdioma", Idioma);
    }
    
    
    /*Método para limpiar los campos de texto, es decir quitar o eliminar la información que haya en ellos,
    y colocar el valor por defecto de los ComboBox.*/
    
    public void limpiar() {
        NombrePuesto.setText(null);
        idPuesto.setText(null);
        Descripcion.setText(null);
        Salario.setText(null);
        PuestoJefSup.setText(null);
        Area.setSelectedItem("Area");
        GradoAvance.setSelectedItem("Grado Avance");
        Edad.setText(null);
        Sexo.setText(null);
        EstadoCivil.setSelectedItem("Estado Civil");
        Escolaridad.setSelectedItem("Escolaridad");
        Experiencia.setText(null);
        Carrera.setSelectedItem("Carrera");
        ManejoEqui.setText(null);
        Conocimientos.setText(null);
        ReqFisic.setText(null);
        ReqPsicol.setText(null);
        Responsabilidades.setText(null);
        CondicionesTrab.setText(null);
        Idioma.setSelectedItem("Idioma");
    }
    
    
    /*Método para inhabilitar los campos de texto y los ComboBox, es decir que no se pueda acceder a ellos
    o que no se pueda modificar su información; esto sirve para consultar todos los datos de un puesto y 
    que no se puedan modificar. */
    
    public void inhabilitar() {
        NombrePuesto.setEditable(false);
        idPuesto.setEditable(false);
        Descripcion.setEditable(false);
        Salario.setEditable(false);
        PuestoJefSup.setEditable(false);
        Area.setEnabled(false);
        GradoAvance.setEnabled(false);
        Edad.setEditable(false);
        Sexo.setEditable(false);
        EstadoCivil.setEnabled(false);
        Escolaridad.setEnabled(false);
        Experiencia.setEditable(false);
        Carrera.setEnabled(false);
        ManejoEqui.setEditable(false);
        Conocimientos.setEditable(false);
        ReqFisic.setEditable(false);
        ReqPsicol.setEditable(false);
        Responsabilidades.setEditable(false);
        CondicionesTrab.setEditable(false);
        Idioma.setEnabled(false);
    }
    
    
    /*Método para habilitar los campos de texto y los ComboBox, es decir que se pueda editar su información
    o modificarla; esto sirve al momento de querer añadir algún puesto o querer modificarlo. */
    
    public void habilitar() {
        NombrePuesto.setEditable(true);
        idPuesto.setEditable(true);
        Descripcion.setEditable(true);
        Salario.setEditable(true);
        PuestoJefSup.setEditable(true);
        GradoAvance.setEnabled(true);
        Area.setEnabled(true);
        Edad.setEditable(true);
        Sexo.setEditable(true);
        EstadoCivil.setEnabled(true);
        Escolaridad.setEnabled(true);
        Experiencia.setEditable(true);
        Carrera.setEnabled(true);
        ManejoEqui.setEditable(true);
        Conocimientos.setEditable(true);
        ReqFisic.setEditable(true);
        ReqPsicol.setEditable(true);
        Responsabilidades.setEditable(true);
        CondicionesTrab.setEditable(true);
        Idioma.setEnabled(true);
    }
    
    
    /*Aquí se inicializan los componentes, es decir, se crean y establecen su características.
    Es un código hecho automáticamente por Java al agregar o modificar un componente. */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Limpiar = new javax.swing.JButton();
        AgregarPuesto = new javax.swing.JButton();
        EliminarPuesto = new javax.swing.JButton();
        EditarPuesto = new javax.swing.JButton();
        Editar = new javax.swing.JButton();
        Agregar = new javax.swing.JButton();
        Regresar = new javax.swing.JButton();
        GradoAvance = new javax.swing.JComboBox<String>();
        Area = new javax.swing.JComboBox<String>();
        Idioma = new javax.swing.JComboBox<String>();
        Escolaridad = new javax.swing.JComboBox<String>();
        EstadoCivil = new javax.swing.JComboBox<String>();
        Carrera = new javax.swing.JComboBox<String>();
        NombrePuesto = new javax.swing.JTextField();
        Descripcion = new javax.swing.JTextField();
        Salario = new javax.swing.JTextField();
        PuestoJefSup = new javax.swing.JTextField();
        Experiencia = new javax.swing.JTextField();
        idPuesto = new javax.swing.JTextField();
        Edad = new javax.swing.JTextField();
        Sexo = new javax.swing.JTextField();
        Responsabilidades = new javax.swing.JTextField();
        ReqFisic = new javax.swing.JTextField();
        ManejoEqui = new javax.swing.JTextField();
        Conocimientos = new javax.swing.JTextField();
        ReqPsicol = new javax.swing.JTextField();
        CondicionesTrab = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaPuesto = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Limpiar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Limpiar.setText("Limpiar");
        Limpiar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(Limpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 580, 130, -1));

        AgregarPuesto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        AgregarPuesto.setText("Agregar puesto");
        AgregarPuesto.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        AgregarPuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarPuestoActionPerformed(evt);
            }
        });
        getContentPane().add(AgregarPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 525, 130, -1));

        EliminarPuesto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        EliminarPuesto.setText("Eliminar puesto");
        EliminarPuesto.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EliminarPuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarPuestoActionPerformed(evt);
            }
        });
        getContentPane().add(EliminarPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 525, 130, -1));

        EditarPuesto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        EditarPuesto.setText("Editar puesto");
        EditarPuesto.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EditarPuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditarPuestoActionPerformed(evt);
            }
        });
        getContentPane().add(EditarPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 525, 115, -1));

        Editar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Editar.setText("Editar");
        Editar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditarActionPerformed(evt);
            }
        });
        getContentPane().add(Editar, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 580, 115, -1));

        Agregar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Agregar.setText("Agregar");
        Agregar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Agregar.setMaximumSize(new java.awt.Dimension(86, 25));
        Agregar.setMinimumSize(new java.awt.Dimension(86, 25));
        Agregar.setPreferredSize(new java.awt.Dimension(86, 25));
        Agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarActionPerformed(evt);
            }
        });
        getContentPane().add(Agregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 580, 130, 29));

        Regresar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Regresar.setText("Regresar");
        Regresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegresarActionPerformed(evt);
            }
        });
        getContentPane().add(Regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 5, 100, 30));

        GradoAvance.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Grado Avance" }));
        GradoAvance.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(GradoAvance, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 305, 130, -1));

        Area.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Area" }));
        Area.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(Area, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 140, 300, -1));

        Idioma.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Idioma" }));
        Idioma.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(Idioma, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 580, 300, -1));

        Escolaridad.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Escolaridad" }));
        Escolaridad.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(Escolaridad, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 305, 200, -1));

        EstadoCivil.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Estado Civil" }));
        EstadoCivil.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(EstadoCivil, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 250, 300, -1));

        Carrera.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Carrera" }));
        Carrera.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(Carrera, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 305, 300, -1));

        NombrePuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombrePuestoActionPerformed(evt);
            }
        });
        getContentPane().add(NombrePuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 85, 200, -1));

        Descripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DescripcionActionPerformed(evt);
            }
        });
        getContentPane().add(Descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 195, 650, -1));

        Salario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalarioActionPerformed(evt);
            }
        });
        getContentPane().add(Salario, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 85, 300, -1));

        PuestoJefSup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PuestoJefSupActionPerformed(evt);
            }
        });
        getContentPane().add(PuestoJefSup, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 340, -1));

        Experiencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExperienciaActionPerformed(evt);
            }
        });
        getContentPane().add(Experiencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 360, 300, -1));

        idPuesto.setEditable(false);
        idPuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idPuestoActionPerformed(evt);
            }
        });
        getContentPane().add(idPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 85, 130, -1));

        Edad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EdadActionPerformed(evt);
            }
        });
        getContentPane().add(Edad, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 200, -1));

        Sexo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SexoActionPerformed(evt);
            }
        });
        getContentPane().add(Sexo, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 250, 130, -1));

        Responsabilidades.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResponsabilidadesActionPerformed(evt);
            }
        });
        getContentPane().add(Responsabilidades, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 525, 650, -1));

        ReqFisic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReqFisicActionPerformed(evt);
            }
        });
        getContentPane().add(ReqFisic, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 470, 300, -1));

        ManejoEqui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ManejoEquiActionPerformed(evt);
            }
        });
        getContentPane().add(ManejoEqui, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 340, -1));

        Conocimientos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConocimientosActionPerformed(evt);
            }
        });
        getContentPane().add(Conocimientos, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 415, 650, -1));

        ReqPsicol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReqPsicolActionPerformed(evt);
            }
        });
        getContentPane().add(ReqPsicol, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 470, 340, -1));

        CondicionesTrab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CondicionesTrabActionPerformed(evt);
            }
        });
        getContentPane().add(CondicionesTrab, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 580, 340, -1));

        jLabel4.setBackground(new java.awt.Color(130, 185, 240));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("Detalles:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 40, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Sexo");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 230, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Salario");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 65, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Puesto del jefe superior");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Estado civil");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 230, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("Área");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 120, -1, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setText("Descripción");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 175, -1, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel12.setText("Edad");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, -1, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setText("ID de puesto");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 65, -1, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setText("Carrera");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 285, -1, -1));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel15.setText("Nombre");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 65, -1, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel16.setText("Experiencia");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 340, -1, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel17.setText("Grado Avance");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 285, -1, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel18.setText("Escolaridad");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 285, -1, -1));

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel19.setText("Conocimientos");
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 395, -1, -1));

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel20.setText("Requisitos físicos");
        getContentPane().add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 450, -1, -1));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel21.setText("Manejo de equipo");
        getContentPane().add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, -1, -1));

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel22.setText("Idioma");
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 560, -1, -1));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel23.setText("Requisitos psicológicos");
        getContentPane().add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, -1, -1));

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel24.setText("Responsabilidades");
        getContentPane().add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 505, -1, -1));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel25.setText("Condiciones de trabajo");
        getContentPane().add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 560, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Puestos");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 5, 100, 30));

        TablaPuesto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        TablaPuesto.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        TablaPuesto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaPuestoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaPuesto);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 60, 600, 438));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Img_Puesto.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, -1, 610));

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setOpaque(true);
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1290, 40));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NombrePuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombrePuestoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombrePuestoActionPerformed

    private void DescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DescripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DescripcionActionPerformed

    private void SalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SalarioActionPerformed

    private void PuestoJefSupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PuestoJefSupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PuestoJefSupActionPerformed

    private void ExperienciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExperienciaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ExperienciaActionPerformed

    private void idPuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idPuestoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idPuestoActionPerformed

    private void EdadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EdadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EdadActionPerformed

    private void SexoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SexoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SexoActionPerformed

    private void ResponsabilidadesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResponsabilidadesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ResponsabilidadesActionPerformed

    private void ReqFisicActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReqFisicActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ReqFisicActionPerformed

    private void ManejoEquiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ManejoEquiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ManejoEquiActionPerformed

    private void ConocimientosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConocimientosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ConocimientosActionPerformed

    private void ReqPsicolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReqPsicolActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ReqPsicolActionPerformed

    private void CondicionesTrabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CondicionesTrabActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CondicionesTrabActionPerformed

    
    /*Método que indica las acciones que realizará el botón Limpiar al ser activado o clickeado.
    Llama al método limpiar(), e inhabilita los botones de editar y eliminar puestos, ya que al
    ser limpiados los campos de texto y los ComboBox no se podrá eliminar el puesto seleccionado
    ni modificar su información. */
    private void LimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LimpiarActionPerformed
        limpiar();
        Editar.setEnabled(false);
        EditarPuesto.setEnabled(false);
        EliminarPuesto.setEnabled(false);
    }//GEN-LAST:event_LimpiarActionPerformed

    
    /*Método que indica las acciones que realizará el boton AgregarPuesto al ser activado o clickeado.
    Llama al método limpiar() para eliminar los datos que haya en los campos de texto o los Combobox, 
    además de habilitarlos para poder escribir o colocar información sobre ellos; a su vez habilita
    los botones de Agregar y Limpiar, e inhabilita los botones de EliminarPuesto, EditarPuesto y Editar.*/
    private void AgregarPuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarPuestoActionPerformed
        limpiar();
        habilitar();
        idPuesto.setEditable(false);
        EditarPuesto.setEnabled(false);
        EliminarPuesto.setEnabled(false);
        Agregar.setEnabled(true); 
        Editar.setEnabled(false);
        Limpiar.setEnabled(true);
        
    }//GEN-LAST:event_AgregarPuestoActionPerformed

    
    /*Método que indica las acciones que realizará el botón EliminarPuesto al ser activado o clickeado.
    Invoca al método eliminarPuesto() de la clase MySQL mediante el objeto creado, y manda como argumento
    el ID del puesto seleccionado para que se borre de la base de datos, luego invoca al método mostrarDatos()
    para que se actualice la tabla en la ventana, después llama al método limpiar() para que se borren los
    datos que había en los campos de texto y los ComboBox, posteriormente inhabilita los botones de editar y 
    eliminar puesto, ya que no se podrá actualizar el puesto que había sido seleccionado ya que fue eliminado
    de la base de datos. */
    private void EliminarPuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarPuestoActionPerformed
        c.eliminarPuesto(Integer.parseInt(idPuesto.getText()));
        mostrarDatos();
        limpiar();
        Editar.setEnabled(false);
        EliminarPuesto.setEnabled(false);
        EditarPuesto.setEnabled(false);
    }//GEN-LAST:event_EliminarPuestoActionPerformed

    
    /*Método que indica las acciones que realizará el botón EditarPuesto al ser activado o clickeado. 
    Habilita el botón Editar y los campos de texto y los ComboBox en el formato; al igual que inhabilita
    el botón de limpiar para no quitar los datos del formato y que se pueda editar de una manera correcta.*/
    private void EditarPuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditarPuestoActionPerformed
        Editar.setEnabled(true);
        habilitar();
        Limpiar.setEnabled(false);
    }//GEN-LAST:event_EditarPuestoActionPerformed

    
    /*Método que indica las acciones que se realizarán al ser clickeado un registro de la tabla que está
    en la ventana. Mediante un try-catch se obtiene la fila seleccionada para poder acceder al ID de ese registro,
    luego se crea el Query para realizar la consulta en la base de datos donde el ID del puesto sea igual que el
    del registro seleccionado en la tabla, después se ejecuta y los valores devueltos se almacenan en una variable
    de ResultSet, y mientras esa variable tenga datos almacenados se colocarán en los campos de texto y los ComboBox
    del formato los datos que le corresponden a cada uno, esto accediendo a los valores que se han guardado en la 
    variable de ResultSet. Lo mismo que se hace con la tabla Puesto, se hace con los catálogos.
    Si ocurre un error se mostrará en mensaje. Luego de esto, se inhabilitan los campos y ComboBox en el formato,
    al igual que los botones Agregar y Editar, en cambio los botones AgregarPuesto y EditarPuesto se habilitan. */
    private void TablaPuestoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaPuestoMouseClicked
        try {  
            int filaselec = TablaPuesto.rowAtPoint(evt.getPoint());
            int idpues =  Integer.parseInt(TablaPuesto.getValueAt(filaselec, 0).toString());
            String Query = "SELECT a.idPuesto, a.NombrePuesto, a.Puesto_jefesup, a.Salario, a.Descripcion, a.Edad, "
                    + "a.Sexo, a.Experiencia, a.Conocimientos, a.ManejoEquipo, a.Reqfisicos, a.Reqpsicol, "
                    + "a.Responsabilidades, a.CondicionesTrab from puesto a where a.idPuesto= "+idpues;
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(Query);
            while (rs.next()) {
                NombrePuesto.setText(rs.getString("NombrePuesto"));
                idPuesto.setText(rs.getString("idPuesto"));
                Descripcion.setText(rs.getString("Descripcion"));
                PuestoJefSup.setText(rs.getString("Puesto_jefesup"));
                Salario.setText(rs.getString("Salario"));
                Edad.setText(rs.getString("Edad"));
                Sexo.setText(rs.getString("Sexo"));
                Experiencia.setText(rs.getString("Experiencia"));
                Conocimientos.setText(rs.getString("Conocimientos"));
                ManejoEqui.setText(rs.getString("ManejoEquipo"));
                ReqPsicol.setText(rs.getString("Reqpsicol"));
                ReqFisic.setText(rs.getString("Reqfisicos"));
                Responsabilidades.setText(rs.getString("Responsabilidades"));
                CondicionesTrab.setText(rs.getString("CondicionesTrab"));
            }
            String query = "select b.NombreCarre from carrera b join puesto a on a.idCarrera=b.idCarrera "
                    + "where a.idPuesto="+idpues;
            rs = st.executeQuery(query);
            if (rs.next()) {
                Carrera.setSelectedItem(rs.getString("NombreCarre"));
            } else {
                Carrera.setSelectedIndex(0);
            }
            
            String query1 = "select b.EstadoCiv from edocivil b join puesto a on a.idEstadoCivil=b.idEdoCivil "
                    + "where a.idPuesto="+idpues;
            rs = st.executeQuery(query1);
            if (rs.next()) {
                EstadoCivil.setSelectedItem(rs.getString("EstadoCiv"));
            } else {
                EstadoCivil.setSelectedIndex(0);
            }
             
            String query2 = "select b.NombreEsco from escolaridad b join puesto a on a.idEscolaridad=b.idEscolaridad "
                    + "where a.idPuesto="+idpues;
            rs = st.executeQuery(query2);
            if (rs.next()) {
                Escolaridad.setSelectedItem(rs.getString("NombreEsco"));
            } else {
                Escolaridad.setSelectedIndex(0);
            }
            
            String query3 = "select b.NombreGA from gdoavance b join puesto a on a.idGradoAvance=b.idGdoAvance "
                    + "where a.idPuesto="+idpues;
            rs = st.executeQuery(query3);
            if (rs.next()) {
                GradoAvance.setSelectedItem(rs.getString("NombreGA"));
            } else {
                GradoAvance.setSelectedIndex(0);
            }
            
            String query4 = "select b.NomIdioma from idioma b join puesto a on a.idIdioma=b.idIdioma "
                    + "where a.idPuesto="+idpues;
            rs = st.executeQuery(query4);
            if (rs.next()) {
                Idioma.setSelectedItem(rs.getString("NomIdioma"));
            } else {
                Idioma.setSelectedIndex(0);
            }
            
            String query5 = "select b.NombreArea from area b join puesto a on a.idArea=b.idArea "
                    + "where a.idPuesto="+idpues;
            rs = st.executeQuery(query5);
            if (rs.next()) {
                Area.setSelectedItem(rs.getString("NombreArea"));
            } else {
                Area.setSelectedIndex(0);
            }
            
        } catch (NumberFormatException | SQLException e){
            JOptionPane.showMessageDialog(null, "Error al mostrar los datos "+e.getMessage());
        }
        
        inhabilitar();
        Agregar.setEnabled(false);
        Editar.setEnabled(false);
        EditarPuesto.setEnabled(true);
        EliminarPuesto.setEnabled(true);
    }//GEN-LAST:event_TablaPuestoMouseClicked

    
    /*Método que indica las acciones que realizará el botón Editar al ser activado o clickeado. 
    Lo primero que hace es validar o corroborar que todos los campos no sean nulos o vacíos y que
    los ComboBox no tengan seleccionado su ítem por defecto. Si la condición es verdadera, entonces,
    mediante un try-catch, se obtienen los ID's de los registros de los catálogos que han sido 
    seleccionados en el formato, esos valores se almacenan en una variable de ResultSet, y con ayuda
    del operador ternario se accede a ese valor almacenado en la variable, según sea el caso o catálogo,
    y se le asigna ese dato a una variable de tipo int, que corresponde al ID. Luego de tener todos 
    los ID's se invoca al método editarPuesto() de la clase MySQL, y se envía como argumentos el ID del
    puesto seleccionado, su nombre, salario, etc., junto con los ID's de los catálogos que se obtuvieron
    previamente; si ese método devuelve la variable boolean verdadera entonces se habrá actualizado 
    el puesto en la base de datos, y se proseguirá con limpiar el formato, inhabilitar sus campos y 
    ComboBox, inhabilitar los botones de editar y eliminar puestos, y el botón de limpiar se habilitará.
    Si ocurre un error se mostrará en mensaje, y por ultimo se muestran los datos actualizados en la tabla.
    Si la condición principal es falsa, se mostrará un mensaje pidiendo que se llenen correctamente los 
    campos. */
    private void EditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditarActionPerformed
        if (NombrePuesto.getText()!=null && Descripcion.getText()!=null && PuestoJefSup.getText()!=null && Area.getSelectedItem()!= "Area" 
            && Salario.getText()!=null && Edad.getText()!=null && Sexo.getText()!=null && EstadoCivil.getSelectedItem()!="Estado Civil" 
            && Escolaridad.getSelectedItem()!="Escolaridad" && GradoAvance.getSelectedItem()!="Grado Avance" 
            && Carrera.getSelectedItem()!="Carrera" && ManejoEqui.getText()!=null && Experiencia.getText()!=null 
            && Conocimientos.getText()!=null && ReqPsicol.getText()!=null && ReqFisic.getText()!=null && Responsabilidades.getText()!=null 
            && CondicionesTrab.getText()!=null && Idioma.getSelectedItem()!="Idioma" && !NombrePuesto.getText().trim().isEmpty() 
            && !Descripcion.getText().trim().isEmpty() && !PuestoJefSup.getText().trim().isEmpty() && !Salario.getText().trim().isEmpty() 
            && !Edad.getText().trim().isEmpty() && !Sexo.getText().trim().isEmpty() && !ManejoEqui.getText().trim().isEmpty() 
            && !Experiencia.getText().trim().isEmpty() && !Conocimientos.getText().trim().isEmpty() && !ReqPsicol.getText().trim().isEmpty()
            && !ReqFisic.getText().trim().isEmpty() && !Responsabilidades.getText().trim().isEmpty() && !CondicionesTrab.getText().trim().isEmpty()) {
                try {
                    String Query = "SELECT idArea FROM area WHERE NombreArea='"+Area.getSelectedItem()+"'";
                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery(Query);
                    int idarea = (rs.next()) ? rs.getInt("idArea") : Area.getSelectedIndex();
                    
                    String Query2 = "SELECT idCarrera FROM carrera WHERE NombreCarre='"+Carrera.getSelectedItem()+"'";
                    rs = st.executeQuery(Query2);
                    int idcarre = (rs.next()) ? rs.getInt("idCarrera") : Carrera.getSelectedIndex();
                    
                    String Query3 = "SELECT idEscolaridad FROM escolaridad WHERE NombreEsco='"+Escolaridad.getSelectedItem()+"'";
                    rs = st.executeQuery(Query3);
                    int idesco = (rs.next()) ? rs.getInt("idEscolaridad") : Escolaridad.getSelectedIndex();
                    
                    String Query4 = "SELECT idEdoCivil FROM edocivil WHERE EstadoCiv='"+EstadoCivil.getSelectedItem()+"'";
                    rs = st.executeQuery(Query4);
                    int idedocivil = (rs.next()) ? rs.getInt("idEdoCivil") : EstadoCivil.getSelectedIndex();
                    
                    String Query5 = "SELECT idGdoAvance FROM gdoavance WHERE NombreGA='"+GradoAvance.getSelectedItem()+"'";
                    rs = st.executeQuery(Query5);
                    int idgdoava = (rs.next()) ? rs.getInt("idGdoAvance") : GradoAvance.getSelectedIndex();
                    
                    String Query6 = "SELECT idIdioma FROM idioma WHERE NomIdioma='"+Idioma.getSelectedItem()+"'";
                    rs = st.executeQuery(Query6);
                    int ididioma = (rs.next()) ? rs.getInt("idIdioma") : Idioma.getSelectedIndex();
                    
                    if (c.editarPuesto(Integer.parseInt(idPuesto.getText()), NombrePuesto.getText().trim(), PuestoJefSup.getText().trim(), 
                        Integer.parseInt(Salario.getText().trim()),Descripcion.getText().trim(), Edad.getText().trim(), Sexo.getText().trim(),
                        Experiencia.getText().trim(), Conocimientos.getText().trim(), ManejoEqui.getText().trim(), 
                        ReqFisic.getText().trim(), ReqPsicol.getText().trim(), Responsabilidades.getText().trim(), 
                        CondicionesTrab.getText().trim(), idarea, idcarre, idesco, idedocivil, idgdoava, ididioma)) {
                        
                            limpiar();
                            inhabilitar();
                            Editar.setEnabled(false);
                            EditarPuesto.setEnabled(false);
                            EliminarPuesto.setEnabled(false);
                            Limpiar.setEnabled(true);
                    }
                    
            } catch (SQLException | NumberFormatException e) { }
        } else {
            JOptionPane.showMessageDialog(null, "Debe llenar todos los campos correctamente");
        }
        mostrarDatos();
    }//GEN-LAST:event_EditarActionPerformed

    
    /*Método que indica las acciones que realizará el botón Agregar al ser activado o clickeado.
    Es muy similar a lo que hace el botón Editar, es decir hace la misma validación, obtiene de la
    misma forma los ID's de los regitros seleccionados de los catálogos, a diferencia de que llama
    al método insertPuesto() de la clase MySQL, y envía como argumentos los textos que se introdujeron
    en los campos de texto, junto con los ID's obtenidos de las consultas correspondientes a cada catálogo.
    Si el método insertPuesto devuelve la variable boolean verdadera, entonces se limpiará el formato,
    pero no se inhabilitarán sus campos y ComboBox por si se quiere seguir agregando puestos; por 
    último se mostrarán los datos actualizados en la tabla.
    Si ocurre un error se mostrará en mensaje. Si la condición principal no se cumple, se mostrará un mensaje 
    diciendo que se deben llenar todos los campos correctamente. */
    private void AgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarActionPerformed
        if (NombrePuesto.getText()!=null && Descripcion.getText()!=null && PuestoJefSup.getText()!=null 
            && Area.getSelectedItem()!= "Area" && Salario.getText()!=null && Edad.getText()!=null && Sexo.getText()!=null 
            && EstadoCivil.getSelectedItem()!="Estado Civil" && Escolaridad.getSelectedItem()!="Escolaridad"
            && GradoAvance.getSelectedItem()!="Grado Avance" && Carrera.getSelectedItem()!="Carrera" && ManejoEqui.getText()!=null 
            && Experiencia.getText()!=null && Conocimientos.getText()!=null && ReqPsicol.getText()!=null && ReqFisic.getText()!=null 
            && Responsabilidades.getText()!=null && CondicionesTrab.getText()!=null && Idioma.getSelectedItem()!="Idioma" 
            && !NombrePuesto.getText().trim().isEmpty() && !Descripcion.getText().trim().isEmpty() && !PuestoJefSup.getText().trim().isEmpty()
            && !Salario.getText().trim().isEmpty() && !Edad.getText().trim().isEmpty() && !Sexo.getText().trim().isEmpty() 
            && !ManejoEqui.getText().trim().isEmpty() && !Experiencia.getText().trim().isEmpty() && !Conocimientos.getText().trim().isEmpty() 
            && !ReqPsicol.getText().trim().isEmpty() && !ReqFisic.getText().trim().isEmpty() 
            && !Responsabilidades.getText().trim().isEmpty() && !CondicionesTrab.getText().trim().isEmpty()) {
                try {
                    String Query = "SELECT idArea FROM area WHERE NombreArea='"+Area.getSelectedItem()+"'";
                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery(Query);
                    int idarea = (rs.next()) ? rs.getInt("idArea") : Area.getSelectedIndex();
                    
                    String Query2 = "SELECT idCarrera FROM carrera WHERE NombreCarre='"+Carrera.getSelectedItem()+"'";
                    rs = st.executeQuery(Query2);
                    int idcarre = (rs.next()) ? rs.getInt("idCarrera") : Carrera.getSelectedIndex();
                    
                    String Query3 = "SELECT idEscolaridad FROM escolaridad WHERE NombreEsco='"+Escolaridad.getSelectedItem()+"'";
                    rs = st.executeQuery(Query3);
                    int idesco = (rs.next()) ? rs.getInt("idEscolaridad") : Escolaridad.getSelectedIndex();
                    
                    String Query4 = "SELECT idEdoCivil FROM edocivil WHERE EstadoCiv='"+EstadoCivil.getSelectedItem()+"'";
                    rs = st.executeQuery(Query4);
                    int idedocivil = (rs.next()) ? rs.getInt("idEdoCivil") : EstadoCivil.getSelectedIndex();
                    
                    String Query5 = "SELECT idGdoAvance FROM gdoavance WHERE NombreGA='"+GradoAvance.getSelectedItem()+"'";
                    rs = st.executeQuery(Query5);
                    int idgdoava = (rs.next()) ? rs.getInt("idGdoAvance") : GradoAvance.getSelectedIndex();
                    
                    String Query6 = "SELECT idIdioma FROM idioma WHERE NomIdioma='"+Idioma.getSelectedItem()+"'";
                    rs = st.executeQuery(Query6);
                    int ididioma = (rs.next()) ? rs.getInt("idIdioma") : Idioma.getSelectedIndex();
                    
                    if (c.insertPuesto(NombrePuesto.getText().trim(), PuestoJefSup.getText().trim(), Integer.parseInt(Salario.getText().trim()),
                        Descripcion.getText().trim(),Edad.getText().trim(), Sexo.getText().trim(), Experiencia.getText().trim(), 
                        Conocimientos.getText().trim(), ManejoEqui.getText().trim(), ReqFisic.getText().trim(),ReqPsicol.getText().trim(), 
                        Responsabilidades.getText().trim(), CondicionesTrab.getText().trim(), idarea, idcarre, idesco, idedocivil, 
                        idgdoava, ididioma)) {
                        
                            limpiar();
                    }
                    
                } catch (SQLException | NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Error al agregar puesto "+e.toString());
                }      
        } else { 
            JOptionPane.showMessageDialog(null, "Debe llenar todos los campos correctamente");
        }
        mostrarDatos();
    }//GEN-LAST:event_AgregarActionPerformed

    
    /*Método que indica las acciones que realizará el botón Regresar al ser activado o clickeado.
    Lo que hace es crear un objeto del jFrame Menu, al hacerlo visible significa que se mostrará 
    esa ventana, y a su vez cerrará la pantalla correspondiente a este jFrame y liberará sus
    recursos utilizados para crear y mantener dicha ventana. */
    private void RegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegresarActionPerformed
        try {
            Menu menu = new Menu();
            menu.setVisible(true);
            this.dispose();
        } catch (Exception ex) {
            Logger.getLogger(Puesto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_RegresarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Puesto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Puesto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Puesto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Puesto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Puesto().setVisible(true);
                } catch (Exception ex) {
                    Logger.getLogger(Puesto.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Agregar;
    private javax.swing.JButton AgregarPuesto;
    public javax.swing.JComboBox<String> Area;
    public javax.swing.JComboBox<String> Carrera;
    private javax.swing.JTextField CondicionesTrab;
    private javax.swing.JTextField Conocimientos;
    private javax.swing.JTextField Descripcion;
    private javax.swing.JTextField Edad;
    private javax.swing.JButton Editar;
    private javax.swing.JButton EditarPuesto;
    private javax.swing.JButton EliminarPuesto;
    public javax.swing.JComboBox<String> Escolaridad;
    public javax.swing.JComboBox<String> EstadoCivil;
    private javax.swing.JTextField Experiencia;
    public javax.swing.JComboBox<String> GradoAvance;
    public javax.swing.JComboBox<String> Idioma;
    private javax.swing.JButton Limpiar;
    private javax.swing.JTextField ManejoEqui;
    private javax.swing.JTextField NombrePuesto;
    private javax.swing.JTextField PuestoJefSup;
    private javax.swing.JButton Regresar;
    private javax.swing.JTextField ReqFisic;
    private javax.swing.JTextField ReqPsicol;
    private javax.swing.JTextField Responsabilidades;
    private javax.swing.JTextField Salario;
    private javax.swing.JTextField Sexo;
    private javax.swing.JTable TablaPuesto;
    private javax.swing.JTextField idPuesto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
